CourseScheduler
===============

My goal is to create a limited course scheduling application geared towards students at UGA in the Franklin College of Arts & Sciences. I'm learning Object Oriented Programming using PHP so please bear with me. The inspiration for this comes from a Web Programming group project where this same goal was achieved using Java. 

There will be architectural and design differences from this group project and to my knowledge, I'm not violating the honor code by putting this online.




