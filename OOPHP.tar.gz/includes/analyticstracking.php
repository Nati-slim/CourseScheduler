<!-- Google Analytics Tracking -->
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-9589147-7']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- End Google Analytics -->
<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=8920740;
var sc_invisible=1;
var sc_security="705da947";
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript>
	<div class="statcounter">
		<a title="free hit counters" href="http://statcounter.com/" target="_blank">
		<img class="statcounter" src="http://c.statcounter.com/8920740/0/705da947/1/" alt="free hit counters">
		</a>
	</div>
</noscript>
<!-- End of StatCounter Code for Default Guide -->
