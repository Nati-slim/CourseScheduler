<?php
/**
 * Class to represent a user of the web application
 *
 *
 */
class User{
	private $id;
	private $schedule;

	function __construct($userid,$userschedule){
		$this->id = $userid;
		$this->
	}
}
?>
